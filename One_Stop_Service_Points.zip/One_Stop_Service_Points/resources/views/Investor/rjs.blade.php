<script src="{{'assets/alluser/'}}registration/js/jquery-3.3.1.min.js"></script>
<script src="{{'assets/alluser/'}}registration/js/main.js"></script>
