<!-- LINEARICONS -->
<link rel="stylesheet" href="{{'assets/alluser/'}}registration/fonts/linearicons/style.css">

<!-- STYLE CSS -->
<link rel="stylesheet" href="{{'assets/alluser/'}}registration/css/style.css">
