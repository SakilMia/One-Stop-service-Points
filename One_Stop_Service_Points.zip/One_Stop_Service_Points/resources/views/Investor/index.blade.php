@extends("Investor.master")
@section("content")
<div class="page-content" style="background-image: url('{{'assets/alluser/'}}applyform/images/wizard-v1.jpg'); height: 700px;">
		<h3 class="home-banner-w3">helping you with any of your business needs!</h3>
</div>

@endsection
