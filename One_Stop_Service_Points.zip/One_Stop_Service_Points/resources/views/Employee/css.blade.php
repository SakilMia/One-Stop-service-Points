<link href="{{'assets/alluser/'}}css/bootstrap.css" type="text/css" rel="stylesheet" media="all">
<link href="{{'assets/alluser/'}}css/style.css" type="text/css" rel="stylesheet" media="all">
<!-- font-awesome icons -->
<link href="{{'assets/alluser/'}}css/font-awesome.min.css" rel="stylesheet">
<!-- //Custom Theme files -->
<!-- online-fonts -->
<link href="//fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i"
      rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">


<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<!-- Font-->
<link rel="stylesheet" type="text/css" href="{{'assets/alluser/'}}applyform/css/raleway-font.css">
<link rel="stylesheet" type="text/css" href="{{'assets/alluser/'}}applyform/fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
<!-- Jquery -->
<link rel="stylesheet" href="https://jqueryvalidation.org/files/demo/site-demos.css">
<!-- Main Style Css -->
<link rel="stylesheet" href="{{'assets/alluser/'}}applyform/css/style.css"/>

<link href="{{'assets/alluser/'}}pdf/css/main.css" rel="stylesheet">




<!--===============================================================================================-->
<link rel="icon" type="image/png" href="{{'assets/alluser/'}}login/images/icons/favicon.ico"/>
<!--===============================================================================================-->

<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="{{'assets/alluser/'}}login/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="{{'assets/alluser/'}}login/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="{{'assets/alluser/'}}login/vendor/animate/animate.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="{{'assets/alluser/'}}login/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="{{'assets/alluser/'}}login/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="{{'assets/alluser/'}}login/vendor/select2/select2.min.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="{{'assets/alluser/'}}login/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="{{'assets/alluser/'}}login/css/util.css">
<link rel="stylesheet" type="text/css" href="{{'assets/alluser/'}}login/css/main.css">
<!--===============================================================================================-->
