<script src="<?php echo e('assets/alluser/'); ?>applyform/js/jquery-3.3.1.min.js"></script>
<script src="<?php echo e('assets/alluser/'); ?>applyform/js/jquery.steps.js"></script>
<script src="<?php echo e('assets/alluser/'); ?>applyform/js/main.js"></script>




<!--===============================================================================================-->

<!--===============================================================================================-->
<script src="<?php echo e('assets/alluser/'); ?>login/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script src="<?php echo e('assets/alluser/'); ?>login/vendor/bootstrap/js/popper.js"></script>
<script src="<?php echo e('assets/alluser/'); ?>login/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script src="<?php echo e('assets/alluser/'); ?>login/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script src="<?php echo e('assets/alluser/'); ?>login/vendor/daterangepicker/moment.min.js"></script>
<script src="<?php echo e('assets/alluser/'); ?>login/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="<?php echo e('assets/alluser/'); ?>login/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->

<?php /**PATH C:\xampp\htdocs\laravel\One_Stop_Service_Points\resources\views/Employee/js.blade.php ENDPATH**/ ?>