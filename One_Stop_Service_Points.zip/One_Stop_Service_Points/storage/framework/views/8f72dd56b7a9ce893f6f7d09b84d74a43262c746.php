<aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    OSSP
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="active has-sub">
                            <a class="js-arrow" href="/admin">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>
                        <li>
                            <a href="/employee">
                                <i class="zmdi zmdi-account-o"></i>Employee</a>
                        </li>
                        <li>
                            <a href="/ministry">
                                <i class="zmdi zmdi-account-o"></i>Ministry</a>
                        </li>
                        <li>
                            <a href="/project">
                                <i class="fas fa-table"></i>Project</a>
                        </li>
                         <li>
                            <a href="/admincostestimate">
                                <i class="zmdi zmdi-money"></i>Cost Estimate</a>
                        </li>


                    </ul>
                </nav>
            </div>
        </aside>
<?php /**PATH C:\xampp\htdocs\laravel\One_Stop_Service_Points\resources\views/Admin/sidebar.blade.php ENDPATH**/ ?>