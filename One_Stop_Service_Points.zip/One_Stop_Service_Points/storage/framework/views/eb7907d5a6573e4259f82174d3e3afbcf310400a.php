<?php $__env->startSection("content"); ?>
<div class="page-content" style="background-image: url('<?php echo e('assets/alluser/'); ?>applyform/images/wizard-v1.jpg'); height: 700px;">
		<h3 class="home-banner-w3">helping you with any of your business needs!</h3>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("Investor.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\One_Stop_Service_Points\resources\views/Investor/index.blade.php ENDPATH**/ ?>