<!-- LINEARICONS -->
<link rel="stylesheet" href="<?php echo e('assets/alluser/'); ?>registration/fonts/linearicons/style.css">

<!-- STYLE CSS -->
<link rel="stylesheet" href="<?php echo e('assets/alluser/'); ?>registration/css/style.css">
<?php /**PATH C:\xampp\htdocs\laravel\One_Stop_Service_Points\resources\views/Investor/rcss.blade.php ENDPATH**/ ?>