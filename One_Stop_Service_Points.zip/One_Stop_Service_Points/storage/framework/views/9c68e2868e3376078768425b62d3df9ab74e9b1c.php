<script src="<?php echo e('assets/'); ?>vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="<?php echo e('assets/'); ?>vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="<?php echo e('assets/'); ?>vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="<?php echo e('assets/'); ?>vendor/slick/slick.min.js">
    </script>
    <script src="<?php echo e('assets/'); ?>vendor/wow/wow.min.js"></script>
    <script src="<?php echo e('assets/'); ?>vendor/animsition/animsition.min.js"></script>
    <script src="<?php echo e('assets/'); ?>vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="<?php echo e('assets/'); ?>vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="<?php echo e('assets/'); ?>vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="<?php echo e('assets/'); ?>vendor/circle-progress/circle-progress.min.js"></script>
    <script src="<?php echo e('assets/'); ?>vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="<?php echo e('assets/'); ?>vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="<?php echo e('assets/'); ?>vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="<?php echo e('assets/'); ?>js/main.js"></script><?php /**PATH C:\xampp\htdocs\laravel\One_Stop_Service_Points\resources\views/Admin/js.blade.php ENDPATH**/ ?>