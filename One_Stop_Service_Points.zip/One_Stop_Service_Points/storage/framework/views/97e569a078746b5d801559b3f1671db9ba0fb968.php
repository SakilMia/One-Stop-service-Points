<script src="<?php echo e('assets/alluser/'); ?>registration/js/jquery-3.3.1.min.js"></script>
<script src="<?php echo e('assets/alluser/'); ?>registration/js/main.js"></script>
<?php /**PATH C:\xampp\htdocs\laravel\One_Stop_Service_Points\resources\views/Investor/rjs.blade.php ENDPATH**/ ?>