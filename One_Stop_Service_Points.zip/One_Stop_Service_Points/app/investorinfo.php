<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class investorinfo extends Model
{
    //
}
